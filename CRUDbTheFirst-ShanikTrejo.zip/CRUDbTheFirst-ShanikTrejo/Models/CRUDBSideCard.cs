﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CRUDbTheFirst_ShanikTrejo.Models
{
    public class CRUDBSideCard
    {
        //Tablas del modelo:Aquí van los materiales( Corresponde a una tabla en la DB)
        //Notación de datos en C#
        //Llave primaria autoincremental
        [Key]
        public int Id { get; set; }
        //Validaciones del Atributo:Nombres
        //50 es la longitud máx de la cadena de caracteres y los valores entre las llaves se refiere a posiciones
        [StringLength(50, ErrorMessage = "El {0} debe ser al menos {2} y máximo {1} caracteres", MinimumLength = 3)]
        [Display(Name = "Nombre(s)")]//Como se muestra en el display
        public string Nombres { get; set; }//Atributo 

        //Validaciones del Atributo: Apellidos
        [Required(ErrorMessage = "Los apellidos son obligatorios")]
        [StringLength(50, ErrorMessage = "El {0} debe ser al menos {2} y máximo {1} caracteres", MinimumLength = 3)]
        [Display(Name = "Apellido(s)")]//Como se muestra en el display
        public string Apellidos { get; set; }//Atributo
        //Validaciones del atributo: Cargo
        [Required(ErrorMessage = "El cargo es requerido")]
        [StringLength(50, ErrorMessage = "El {0} debe ser al menos {2} y máximo {1} caracteres", MinimumLength = 3)]

        public string Cargo { get; set; }//Atributo

        [Required(ErrorMessage = "La descripción del cargo es obligatoria")]
        [StringLength(50, ErrorMessage = "El {0} debe ser al menos {2} y máximo {1} caracteres", MinimumLength = 3)]
        [Display(Name = "Descripción del cargo")]//Como se muestra en el display
        //Propiedad o Atributo: Descripción
        public string Descripcion { get; set; }//Atributo: descripción del cargo

        //Validaciones del atributo:Email
        [Required(ErrorMessage = "El correo es obligatorio")]
        [DataType(DataType.EmailAddress)]
        [EmailAddress]
        [Display(Name = "Correo")]//Como se muestra en el display
        public string Email { get; set; }//Atributo

    }
}
