﻿using CRUDbTheFirst_ShanikTrejo.Models;//Instancia a la clase Models
using Microsoft.EntityFrameworkCore;//NuGet utilizado para poder utilizar ApplicationDbContext
using System.Collections.Generic;

namespace CRUDbTheFirst_ShanikTrejo.Data
{
    public class ApplicationDbContext : DbContext
    {
        //constructor
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options){
        }
        //Instancia(bSideCard) al Modelo creado(bSideCard)
        public DbSet<CRUDBSideCard> CRUDBSideCard { get; set; }

    }
}
