﻿using CRUDbTheFirst_ShanikTrejo.Data;//se utiliza para llamar a ApplicationDbContext
using CRUDbTheFirst_ShanikTrejo.Models;//Se utiliza para acceder a los modelos
using Microsoft.AspNetCore.Mvc;// Se utiliza por el framework de ASP.NET 
using System.Collections.Generic;//Para poder usar IEnumarable


namespace CRUDbTheFirst_ShanikTrejo.Controllers
{
    public class BsideCards : Controller
    {
        //Invocación al ApplicationDbContext para acceder a la base de datos
        private readonly ApplicationDbContext _context;
        //Inicialización del acceso a ApplicationDbContext
        public BsideCards(ApplicationDbContext context)
        {
            _context = context;

        }

        //Método
        //Http Get Index
        public IActionResult Index()
        {
            IEnumerable<CRUDBSideCard> listBsideCard = _context.CRUDBSideCard;
            //Se retorna la vista con los parámetros contenidos en listBsideCard

            return View(listBsideCard);
        }
        //Http Get Create
        public IActionResult Create()
        {
            return View();
        }
        //Http Post Create
        [HttpPost]
        //Protección para los formularios
        [ValidateAntiForgeryToken]
        public IActionResult Create(CRUDBSideCard crudbSideCard)
        {
            //Validación del modelo
            if(ModelState.IsValid){
                //Si el modelo es válido entonces se agrega a crudbSideCard
                _context.CRUDBSideCard.Add(crudbSideCard);
                _context.SaveChanges();
                TempData["Mensaje"]="La bSideCard ha sido creada con éxito";
                return RedirectToAction("Index");
            }

            return View();
        }
        //Http Get Edit
        public IActionResult Edit(int? id)
        {
            if (id==null || id==0)
            {
                return NotFound();
            }

            //Obtener la bSideCard
            var card = _context.CRUDBSideCard.Find(id);

            if (card==null)
            {
                return NotFound();
            }
            return View(card);
        }
        //Http Post Edit
        [HttpPost]
        //Protección para los formularios
        [ValidateAntiForgeryToken]
        public IActionResult Edit(CRUDBSideCard crudbSideCard)
        {
            //Validación del modelo
            if (ModelState.IsValid)
            {
                //Si el modelo es válido entonces se agrega a crudbSideCard
                _context.CRUDBSideCard.Update(crudbSideCard);
                _context.SaveChanges();
                TempData["Mensaje"] = "La bSideCard se ha actualizado con éxito";
                return RedirectToAction("Index");
            }

            return View();
        }
        //Http Get Delete
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            //Obtener la bSideCard
            var card = _context.CRUDBSideCard.Find(id);

            if (card == null)
            {
                return NotFound();
            }
            return View(card);
        }
        //Http Post Delete
        [HttpPost]
        //Protección para los formularios
        [ValidateAntiForgeryToken]
        public IActionResult DeletebSideCard(int? id)
        {
            //Obtener la bSideCard por id
            var card = _context.CRUDBSideCard.Find(id);
            //Validación
            if (card==null) {
                return NotFound();
            }
            _context.CRUDBSideCard.Remove(card);
            _context.SaveChanges();
            TempData["Mensaje"] = "La bSideCard se ha eliminado con éxito";
            return RedirectToAction("Index");
        }
       
    }
}
